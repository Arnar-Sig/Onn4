1. Start server using
java ConnectionLessServer (after compiling with javac ConnectionLessServer)

2. Start on same machine client
java ConnectionLessClient . localhost (after compiling with javac ConnectionLessClient)
