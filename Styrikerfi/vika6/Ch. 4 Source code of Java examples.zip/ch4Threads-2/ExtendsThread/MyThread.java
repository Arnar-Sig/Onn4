//package ch4Threads.ExtendsThread;

class MyThread extends Thread {
  public void run() {
    System.out.println("I Am a Further Thread");
  }
}
