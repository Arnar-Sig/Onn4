//package ch4Threads.ImplementsRunnable;

class MyThread2 implements Runnable {
   public void run() {
      System.out.println("I Am a Worker Thread ");
   }
}
