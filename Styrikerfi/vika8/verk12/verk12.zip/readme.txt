1. Start programm using (adjust classpath parameter -cp to let it point to the directory that contains the .class files):

java -cp /home/helmut/workspace/Assignment12/bin/ Assignment12 100

2. No need to answer question from part 2.