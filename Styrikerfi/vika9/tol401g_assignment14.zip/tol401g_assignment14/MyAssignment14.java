// You are free to modify this class, e.g. add fields, methods,
// constructors, extend from class Thread etc. with these two exceptions:
// 1. Do not change the name of this class nor put it into another package
// 2. Do not modify the name and input and output parameter of the main method.

public class MyAssignment14 { // TODO: Modify as necessary

	// TODO: fill in your code here

	public static long main(long iterationsPerThread) { // Do not modify this line!

		// TODO: fill in your code here

	}

}
