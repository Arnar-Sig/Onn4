Start programm using (adjust classpath parameter -cp to let it point to the directory that contains the .class files):

#example
java -cp /home/ingolfuh/workspace/Assignment14/bin/ Assignment14 100
