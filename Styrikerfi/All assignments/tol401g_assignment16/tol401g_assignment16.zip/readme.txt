Start programm using (adjust classpath parameter -cp to let it point to the directory that contains the .class files):

#An example
java -cp /home/ingolfuh/workspace/Assignment16/bin/ Assignment16 100
